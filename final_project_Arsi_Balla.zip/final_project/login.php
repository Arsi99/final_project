<?php session_start();

include('config.php');
if(isset($_POST['login']));
{
    $user_unsafe=$_POST['user_name'];
    $pass_unsafe=$_POST['password'];

    $user = mysqli_real_escape_string($conn,$user_unsafe);
    $pass = mysqli_real_escape_string($conn,$pass_unsafe);

    $query = mysqli_query($conn, "select * from loginform where user_name='$user' and password='$pass'") or die(mysqli_error($conn));

    $row=mysqli_fetch_array($query);

    $name=$row['user_name'];
    $counter=mysqli_num_rows($query);
    $id=$row['id'];

    if ($counter == 0)
    {
        echo "<script type'/javascript'>alert('Invalid Email or Password!');
        document.location='home.php'</script>";
    }
    else{
        $_SESSION['id']=$id;
        $_SESSION['user_name']=$name;

        echo "<script type'/javascript'>document.location='index.php'</script>";

    }

}


?>