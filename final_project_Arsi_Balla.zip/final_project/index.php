<?php
  include 'action.php';
?>

<?php
if(empty($_SESSION['id'])):
header('Location:home.php');
endif;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Arsi Balla">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>FINAL PROJECT</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Bootstrap icons -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
</head>

<body> 
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">CODERSTRUST</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About us</a>
      </li>
    </ul>
  </div>                     
    <a class="text-danger" href="logout.php"><i class="fa fa-sign-out-alt fa-lg"></i></a>
</nav>
<div class="conteiner-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h3 class="text-center text-dark mt-2">Welcome Admin</h3>
            <hr>
            <?php if (isset($_SESSION['response'])) { ?>
              <div class="alert alert-<?= $_SESSION['res_type']; ?> alert-dismissible text-center">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <b><?= $_SESSION['response']; ?></b>
              </div>
        <?php } unset($_SESSION['response']); ?>
      <div class="row">
        <div class="col-md-3">
            <h3 class="text-center text-info">Add Employee</h3>
            <form action="action.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $id; ?>">
                <div class="form-group">
                    <input type="text" name="name" value= "<?= $name; ?>" class="form-control" placeholder="Enter name" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" value= "<?= $email; ?>" class="form-control" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                    <input type="int" name="salary" value= "<?= $salary; ?>" class="form-control" placeholder="Enter salary" required>
                </div>
                <div class="form-group">
                    <input type="date" name="date" value= "<?= $date; ?>" class="form-control" placeholder="Enter date" required>
                </div>
                <div class="form-group">
                    <select name="job" value= "<?= $job; ?>" class="form-control" required>
                      <option value="job">Enter job role</option>
                      <option value="Web developer">Web developer</option>
                      <option value="Operator">Operator</option>
                      <option value="Manager">Manager</option>
                      <option value="IT">IT</option>
                      <option value="Translator">Translator</option>
                      <option value="Receptionist">Receptionist</option>
                    </select>
                </div>
                <div class="form-group">
                    <select name="status" value= "<?= $status; ?>" class="form-control" required>
                      <option value="status">Enter status</option>
                      <option value="hired employee">hired employee</option>
                      <option value="new employee">new employee</option>
                      <option value="fired employee">fired employee</option>
                    </select>
                </div>
                <div class="form-group">
                  <?php if ($update == true) { ?>
                  <input type="submit" name="update" class="btn btn-success btn-block" value="Update Employee">
                  <?php } else { ?>
                  <input type="submit" name="add" class="btn btn-primary btn-block" value="Add Employee">
                  <?php } ?>
                </div>
            </form>
        </div>
        <div class="col-md-9">
        <?php
          $query = 'SELECT * FROM employees';
          $stmt = $conn->prepare($query);
          $stmt->execute();
          $result = $stmt->get_result();
        ?>
        <h3 class="text-center text-info">Employees</h3>
        <table class="table table-hover">
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Salary</th>
        <th>Date</th>
        <th>Job</th>
        <th>Status</th>
        <th>Action</th>        
      </tr>
    </thead>
    <tbody>
    <?php while ($row = $result->fetch_assoc()) { ?>
      <tr>
        <td><?= $row['id']; ?></td>
        <td><?= $row['name']; ?></td>
        <td><?= $row['email']; ?></td>
        <td><?= $row['salary']; ?>$</td>
        <td><?= $row['date']; ?></td>
        <td><?= $row['job']; ?></td>
        <td><?= $row['status']; ?></td>
        <td>
          <a href="details.php?details=<?= $row['id']; ?>" title= "View Details" class="text-success"><i class="fas fa-info-circle fa-lg"></i></a> |
          <a href="action.php?delete=<?= $row['id']; ?>" title= "Delete" class="text-danger" onclick="return confirm('Do you want delete this record?');"><i class="fa fa-trash fa-lg"></i></a> |
          <a href="index.php?edit=<?= $row['id']; ?>" title= "Edit" class="text-primary"><i class="fas fa-edit fa-lg"></a> 
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
        </div>
    </div>
</div>    
</body>
</html>