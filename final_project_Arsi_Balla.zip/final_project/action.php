<?php
	session_start();
	include 'config.php';

    // ADD EMPLOYEES
	$update=false;
	$id="";
	$name="";
	$email="";
	$salary="";
	$date="";
    $job="";
    $status="";

	if(isset($_POST['add'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$salary=$_POST['salary'];
        $date=$_POST['date'];
        $job=$_POST['job'];
        $status=$_POST['status'];

		$query="INSERT INTO employees(name,email,salary,date, job, status)VALUES(?,?,?,?,?,?)";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("ssssss",$name,$email,$salary,$date,$job,$status);
		$stmt->execute();

		header('location:index.php');
		$_SESSION['response']="Successfully Inserted to the database!";
		$_SESSION['res_type']="success";
	}

    // DELETE EMPLOYEES
	if(isset($_GET['delete'])){
		$id=$_GET['delete'];

		$query="DELETE FROM employees WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();

		header('location:index.php');
		$_SESSION['response']="Successfully Deleted!";
		$_SESSION['res_type']="danger";
	}

    // EDIT EMPLOYEES INFORMATION
	if(isset($_GET['edit'])){
		$id=$_GET['edit'];

		$query="SELECT * FROM employees WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result=$stmt->get_result();
		$row=$result->fetch_assoc();

		$id=$row['id'];
		$name=$row['name'];
		$email=$row['email'];
		$salary=$row['salary'];
		$date=$row['date'];
        $job=$row['job'];
		$status=$row['status'];

		$update=true;
	}

    // UPDATE EMPLOYEES INFRMATION
	if(isset($_POST['update'])){
		$id=$_POST['id'];
		$name=$_POST['name'];
		$email=$_POST['email'];
		$salary=$_POST['salary'];
		$date=$_POST['date'];
        $job=$_POST['job'];
		$status=$_POST['status'];

		$query="UPDATE employees SET name=?,email=?,salary=?,date=?,job=?,status=? WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("ssssssi",$name,$email,$salary,$date,$job,$status,$id);
		$stmt->execute();

		$_SESSION['response']="Updated Successfully!";
		$_SESSION['res_type']="primary";
		header('location:index.php');
	}

    // DETAILS OF EMPLOYEES
	if(isset($_GET['details'])){
		$id=$_GET['details'];
		$query="SELECT * FROM employees WHERE id=?";
		$stmt=$conn->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result=$stmt->get_result();
		$row=$result->fetch_assoc();

		$vid=$row['id'];
		$vname=$row['name'];
		$vemail=$row['email'];
		$vsalary=$row['salary'];
		$vdate=$row['date'];
        $vjob=$row['job'];
		$vstatus=$row['status'];
	}


