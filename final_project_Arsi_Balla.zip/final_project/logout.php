<?php session_start();
if(empty($_SESSION['id'])):
header('Location:home.php');
endif;
?>

<?php
include('config.php');
session_destroy();

echo '<meta http-equive="refresh" content="2;url=home.php">';
echo '<progress max=100><strong>Progress: 60% done.</strong></progress><br>';
echo '<span class="itext">Logging out, please wait...</span>';

header("Location: home.php");

 ?>